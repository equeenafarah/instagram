<?php
// session_start();

// if(!isset($_SESSION['login'])) {
//     header("location:login.php?pesan=logindulu");
// }

include "koneksi.php";

$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no = '$no' ";
$query = mysqli_query($koneksi, $sql);
while ($post = mysqli_fetch_assoc($query)) {
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SAWEB</title>
    <link rel="shortcut icon" href="(logo)" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body>

    <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
    <a class = "navbar-brand" href = "index.php">
    <img src = "aisa.png" width = "30" height = "30">
    </a>

    <a class="navbar-brand" href="index.php">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
    <div class="navbar-nav">
    <a class="navbar-brand" href="logout.php">Logout</a>
    </div>
    </div>
    </div>
    </nav>

    <br>
    <div class="container">
    <h1 align="center">Edit</h1>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <form action="proses_edit.php" method="post" enctype="multipart/form-data">

    <input type="hidden" name="no" value="<?= $post['no'] ?>">
    <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
        
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br>
        <img src="gambar/<?= $post['gambar'] ?>" width="200" alt="" ><br><br>

        <div class="col-auto">
        <label class="form-label" for="">Caption</label>
        </div>

        <input class="form-control" type="text" name="caption"value="<?= $post['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off"><br>


    <button type="submit" class="btn btn-primary" value="Update" name="update">Ubah</button>

    </form>
</body>
</html>
<?php } ?>
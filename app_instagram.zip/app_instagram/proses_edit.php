<?php
include "koneksi.php";
require "functions.php";

if (isset($_POST['update'])) {
    $no = $_POST['no'];
    $caption = $_POST['caption'];
    $lokasi = $_POST['lokasi'];
    $gambar_lama = $_POST['gambar_lama'];
    $gambar_baru = $_FILES['gambar']['name'];

    // jika gambarnya sama, pakai foto yang lama
    if( $_FILES['gambar']['error'] === 4 ) {
		$gambar = $gambar_lama;
	} else {
        $sql = "SELECT * FROM post WHERE no = '$no' ";
        $query = mysqli_query($koneksi, $sql);
    
        // menghapus foto lama karena nanti akan diganti yang baru
        while($post = mysqli_fetch_assoc($query)) {
            $gambar = $post['gambar'];
            unlink('images/' . $gambar);
        }

        // lakukan proses upload gambar baru
		$gambar = upload();
	}
    
    $sql2 = "UPDATE post SET caption = '$caption', lokasi = '$lokasi', gambar = '$gambar' WHERE no = '$no' ";
    $query2 = mysqli_query($koneksi, $sql2);

    if ($query2) {
        header("location:index.php?edit=sukses");
    } else {
        header("location:index.php?edit=gagal");
    }
    
}
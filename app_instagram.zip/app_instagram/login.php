<!DOCTYPE html>
<html lang="en">
<head>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
<link rel="shortcut icon" href="dino2.png">
    <title>Login</title>
</head>
<center>
<body>
  <style>
    body {
  background: #D8D9DA;
  background-image: url('abuabu.jpg');
  background-position: absolute;
  background-size: 1500px;
}
  </style>
<div class="container">
  <div class="col-md-4">
    <div class="card-header">
  <img src="dino2.png" width="200" height="250">
  <div class="card-body"></div>
<h1 align="center">login</h1>
    <form action="proses_login.php" method="post">
<form>
  <div class="form-group">
    <label for="">Username</label>
    <input type="text" name="username" id="" class="form-control">
  
  <div class="form-group">
    <label for="">Password</label>
    <input type="password" name="password" id="" class="form-control"><br>

  <div class="form-group"> </div>
  <input type="submit" value="login" class="btn btn-primary">
</form>
</body>
</center>
</html>
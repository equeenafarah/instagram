<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-AU-Compatible" content="IE-edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Tambah</h1>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">

        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" required><br><br>

        <label for="">Caption</label><br>
        <input type="text" name="caption" id="" autocomplete="off"><br><br>

        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" autocomplete="off"><br><br>

        <input type="submit" value="Simpan" name="simpan">
    </form>
</body>
</html>
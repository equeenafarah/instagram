<?php 
session_start();
if (!isset($_SESSION['login'])) {
    header ("location:login.php?pesan=logindulu");
}

include "koneksi.php";
$sql = "SELECT * FROM post";
$query = mysqli_query($koneksi,$sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
<link rel="shortcut icon" href="dino2.png" type="imagle/x-icon">
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <center>
    <style>
        .card-img-top {
            transition: transform 0.3s; /* Add a transition effect for smooth zoom */
        }
        .card-img-top:hover {
            transform: scale(1.1); /* Increase the scale on hover (adjust the value as needed) */
  }

  body {
  background: #D8D9DA;
  background-image: url('dino.jpg');
  background-position: absolute;
  background-size: 150px;
}
    </style>
    <title>🅷🅰🅻🆄🅸🅽🅳🆄🅻🆄</title>
    
    <link rel="stylesheet" href="css/bootstrap.min (9).css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.min.js" integrity="sha384-BBtl+eGJRgqQAUMxJ7pMwbEyER4l1g+O15P+16Ep7Q9Q+zqX6gSbd85u4mG4QzX+" crossorigin="anonymous"></script>
    
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-dark fixed-top">
  <div class="container-fluid">
    <img src="dino2.png" width="50px" alt="">
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarTogglerDemo03" aria-controls="navbarTogglerDemo03" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <a class="nav-link disabled" href="#" aria-disabled="true" color="red">🅷🅰🅻🆄🅸🅽🅳🆄🅻🆄</a>
    <div class="collapse navbar-collapse" id="navbarTogglerDemo03">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
      </ul>
      <a href="#" class="nav-link"><button type="submit" class="btn btn-outline-light" data-bs-toggle="modal" data-bs-target="#exampleModal" ><i class="fa fa-plus-square"></i></button></a>
      <a href="logout.php"><button class="btn btn-secondary">Log Out</button></a>
    </div>
  </div>
</nav>    <br><br><br><br>

    <div class="container">    
    <?php while($post = mysqli_fetch_assoc($query)) { ?>
    <div class="card" style="width: 18rem;">
    <div class ="zoom">
  <img class="card-img-top" src="images/<?= $post['gambar'] ?>" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title"><?= $post['caption'] ?></h5>
    <p class="card-text"><?= $post['lokasi'] ?></p> 

    <button type="submit" class="btn btn-outline-dark" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no'] ?>"><i class="fa fa-pencil"></i></button>
    <a href="hapus.php?no=<?= $post['no'] ?>" class="btn btn-danger"><i class="fa fa-trash" style="font-size:24px"></i></a>
    
    <!-- modal edit -->
  <div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">Edit</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_edit.php" method="post" enctype="multipart/form-data">
  <input type="hidden" name="no" value="<?= $post['no'] ?>">
    <input type="hidden" name="foto_lama" value="<?= $post['gambar'] ?>">
    
        <label class="form-label" for="">Gambar</label>
        <input class="form-control" type="file" name="gambar" id="" value="<?= $post['gambar'] ?>" ><br>
        <img src="gambar/<?= $post['gambar'] ?>" width="200" alt="" ><br><br>

        <div class="col-auto">
        <label class="form-label" for="">Caption</label>
        </div>

        <input class="form-control" type="text" name="caption"value="<?= $post['caption'] ?>" id="" autocomplete="off"><br>

        <label class="form-label" for="">Lokasi</label>
        <input class="form-control" type="text" name="lokasi" value="<?= $post['lokasi'] ?>" id="" autocomplete="off"><br>


    <button type="submit" class="btn btn-dark" value="Update" name="update">Ubah</button>

    </form>
  </div>
  </div>
  </div>
</div>
  </div>
  </div>
  </div> 
  </div>
</div><br><br>
<?php }?>
</div>
</center>

<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
  <div class="modal-content">
  <div class="modal-header">
  <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
  <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
  </div>

  <div class="modal-body">
  <form action="proses_tambah.php" method="post"enctype="multipart/form-data">
  <label for="">Gambar</label>
  <input type="file" name="gambar" class="form-control" id="" required><br>

  <label for="">Caption</label>
  <input type="text" name="caption" class="form-control" id="" autocomplete="off"><br>

  <label for="">Lokasi</label>
  <input type="text" name="lokasi" class="form-control" id=""><br>

  <input type="submit" value="Simpan" name="simpan" class="btn btn-outline-dark">

  </form>
  </div>
  </div>
  </div>
</div>

</body>
</html>